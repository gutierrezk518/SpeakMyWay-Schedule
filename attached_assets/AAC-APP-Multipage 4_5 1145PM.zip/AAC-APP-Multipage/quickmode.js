// quickmode.js - Functionality for the Quick Mode page

// Default feelings
const defaultFeelings = [
    { id: 101, name: "Happy", image: "https://cdn-icons-png.flaticon.com/128/742/742751.png", type: "feeling", color: "#2ecc71" },
    { id: 102, name: "Sad", image: "https://cdn-icons-png.flaticon.com/128/742/742752.png", type: "feeling", color: "#3498db" },
    { id: 103, name: "Angry", image: "https://cdn-icons-png.flaticon.com/128/742/742744.png", type: "feeling", color: "#e74c3c" },
    { id: 104, name: "Tired", image: "https://cdn-icons-png.flaticon.com/128/742/742784.png", type: "feeling", color: "#9b59b6" },
    { id: 105, name: "Hungry", image: "https://cdn-icons-png.flaticon.com/128/1791/1791341.png", type: "feeling", color: "#f39c12" },
    { id: 106, name: "Frustrated", image: "https://cdn-icons-png.flaticon.com/128/742/742760.png", type: "feeling", color: "#d35400" },
    { id: 107, name: "Excited", image: "https://cdn-icons-png.flaticon.com/128/742/742745.png", type: "feeling", color: "#f1c40f" },
    { id: 108, name: "Scared", image: "https://cdn-icons-png.flaticon.com/128/742/742753.png", type: "feeling", color: "#7f8c8d" },
    { id: 109, name: "Bored", image: "https://cdn-icons-png.flaticon.com/128/742/742770.png", type: "feeling", color: "#95a5a6" },
    { id: 110, name: "Sick", image: "https://cdn-icons-png.flaticon.com/128/2659/2659806.png", type: "feeling", color: "#e74c3c" },
    { id: 111, name: "Confused", image: "https://cdn-icons-png.flaticon.com/128/742/742758.png", type: "feeling", color: "#9b59b6" },
    { id: 112, name: "Calm", image: "https://cdn-icons-png.flaticon.com/128/742/742774.png", type: "feeling", color: "#3498db" }
];

// Default wants
const defaultWants = [
    { id: 201, name: "Water", image: "https://cdn-icons-png.flaticon.com/128/3248/3248369.png", type: "want", color: "#3498db" },
    { id: 202, name: "Food", image: "https://cdn-icons-png.flaticon.com/128/1046/1046857.png", type: "want", color: "#e67e22" },
    { id: 203, name: "Bathroom", image: "https://cdn-icons-png.flaticon.com/128/2452/2452300.png", type: "want", color: "#9b59b6" },
    { id: 204, name: "Break", image: "https://cdn-icons-png.flaticon.com/128/2920/2920306.png", type: "want", color: "#e74c3c" },
    { id: 205, name: "Play", image: "https://cdn-icons-png.flaticon.com/128/2790/2790806.png", type: "want", color: "#2ecc71" },
    { id: 206, name: "Music", image: "https://cdn-icons-png.flaticon.com/128/651/651799.png", type: "want", color: "#f1c40f" },
    { id: 207, name: "Hug", image: "https://cdn-icons-png.flaticon.com/128/2454/2454299.png", type: "want", color: "#e67e22" },
    { id: 208, name: "Help", image: "https://cdn-icons-png.flaticon.com/128/1662/1662341.png", type: "want", color: "#c0392b" },
    { id: 209, name: "TV", image: "https://cdn-icons-png.flaticon.com/128/2982/2982606.png", type: "want", color: "#3498db" },
    { id: 210, name: "Outside", image: "https://cdn-icons-png.flaticon.com/128/1329/1329016.png", type: "want", color: "#27ae60" },
    { id: 211, name: "Tablet", image: "https://cdn-icons-png.flaticon.com/128/821/821749.png", type: "want", color: "#9b59b6" },
    { id: 212, name: "Book", image: "https://cdn-icons-png.flaticon.com/128/2436/2436882.png", type: "want", color: "#16a085" }
];

// Active collections
let myFeelings = [...defaultFeelings];
let myWants = [...defaultWants];

// Initialize the quick mode page
function initQuickMode() {
    // Initialize feelings grid
    initFeelings();

    // Initialize wants grid
    initWants();
}

// Initialize feelings grid
function initFeelings() {
    const grid = document.getElementById('feelings-grid');
    if (!grid) return;

    grid.innerHTML = '';

    myFeelings.forEach(feeling => {
        const card = document.createElement('div');
        card.className = 'feeling-card';
        card.setAttribute('data-id', feeling.id);
        card.style.backgroundColor = feeling.color;

        card.innerHTML = `
            <img src="${feeling.image}" alt="${feeling.name}">
            <p>${feeling.name}</p>
        `;

        // Add click event for text-to-speech and selection
        card.addEventListener('click', function() {
            // Speak the feeling
            speak(`I am feeling ${feeling.name}`);

            // Update the current feeling display
            selectFeeling(feeling);

            // Show notification
            showNotification(`I am feeling ${feeling.name}`);
        });

        grid.appendChild(card);
    });
}

// Initialize wants grid
function initWants() {
    const grid = document.getElementById('wants-grid');
    if (!grid) return;

    grid.innerHTML = '';

    myWants.forEach(want => {
        const card = document.createElement('div');
        card.className = 'want-card';
        card.setAttribute('data-id', want.id);
        card.style.backgroundColor = want.color;

        card.innerHTML = `
            <img src="${want.image}" alt="${want.name}">
            <p>${want.name}</p>
        `;

        // Add click event for text-to-speech and selection
        card.addEventListener('click', function() {
            // Speak the want
            speak(`I would like ${want.name}`);

            // Update the current want display
            selectWant(want);

            // Show notification
            showNotification(`I would like ${want.name}`);
        });

        grid.appendChild(card);
    });
}

// Select a feeling
function selectFeeling(feeling) {
    const currentFeeling = document.getElementById('current-feeling');
    if (!currentFeeling) return;

    currentFeeling.innerHTML = '';

    const card = document.createElement('div');
    card.className = 'feeling-card';
    card.style.backgroundColor = feeling.color;

    card.innerHTML = `
        <img src="${feeling.image}" alt="${feeling.name}">
        <p>${feeling.name}</p>
    `;

    currentFeeling.appendChild(card);
}

// Select a want
function selectWant(want) {
    const currentWant = document.getElementById('current-want');
    if (!currentWant) return;

    currentWant.innerHTML = '';

    const card = document.createElement('div');
    card.className = 'want-card';
    card.style.backgroundColor = want.color;

    card.innerHTML = `
        <img src="${want.image}" alt="${want.name}">
        <p>${want.name}</p>
    `;

    currentWant.appendChild(card);
}

// Initialize the page when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM loaded for quick mode page");
    initQuickMode();
});

// Also initialize if DOM is already loaded
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    console.log("DOM already loaded, initializing quick mode page now");
    initQuickMode();
}