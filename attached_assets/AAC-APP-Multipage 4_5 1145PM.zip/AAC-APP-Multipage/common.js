// common.js - Shared functionality across all pages

// Voice settings that will be customizable
let voiceSettings = {
    voiceURI: "", // Will be set based on available voices
    rate: 1.0,    // Speed: 0.5 to 1.5
    pitch: 1.0,   // Pitch: 0.5 to 1.5
    volume: 1.0   // Volume: 0.1 to 1.0
};

// Load saved voice settings if available
function loadVoiceSettings() {
    const savedSettings = localStorage.getItem('aacVoiceSettings');
    if (savedSettings) {
        try {
            voiceSettings = JSON.parse(savedSettings);
        } catch (e) {
            console.error("Error loading voice settings:", e);
            // If there's an error, we'll just use the defaults
        }
    }
}

// Save voice settings to localStorage
function saveVoiceSettings() {
    localStorage.setItem('aacVoiceSettings', JSON.stringify(voiceSettings));
}

// Initialize voice settings on load
loadVoiceSettings();

// Check if speech synthesis is available
const speechSynthesisAvailable = 'speechSynthesis' in window;
console.log("Speech synthesis available:", speechSynthesisAvailable);

// Unlock speech synthesis on first user interaction (needed for some browsers)
function unlockSpeechSynthesis() {
    if (!speechSynthesisAvailable) return;

    document.addEventListener('click', function unlockSpeech() {
        const unlockUtterance = new SpeechSynthesisUtterance('');
        unlockUtterance.volume = 0;
        window.speechSynthesis.speak(unlockUtterance);

        document.removeEventListener('click', unlockSpeech);
        console.log("Speech synthesis unlocked by user interaction");
    }, { once: true });
}

// Call unlock function on page load
unlockSpeechSynthesis();

// Text-to-speech functionality
function speak(text) {
    console.log("Speaking:", text);

    if (!speechSynthesisAvailable) {
        console.error("Speech synthesis not available");
        return null;
    }

    try {
        // Cancel any ongoing speech
        window.speechSynthesis.cancel();

        // Create a new speech utterance
        const utterance = new SpeechSynthesisUtterance(text);

        // Configure voice settings
        utterance.rate = voiceSettings.rate;
        utterance.pitch = voiceSettings.pitch;
        utterance.volume = voiceSettings.volume;

        // Use the selected voice if available
        if (voiceSettings.voiceURI) {
            const voices = window.speechSynthesis.getVoices();
            const selectedVoice = voices.find(voice => voice.voiceURI === voiceSettings.voiceURI);
            if (selectedVoice) {
                utterance.voice = selectedVoice;
            }
        }

        // Speak the text
        window.speechSynthesis.speak(utterance);

        // Show speech indicator in message bar if it exists
        const messageBar = document.getElementById('message-bar');
        if (messageBar) {
            const speechText = document.createElement('span');
            speechText.className = 'speech-text';
            speechText.textContent = ` "${text}" `;
            messageBar.appendChild(speechText);

            // Remove the text after speaking is done
            utterance.onend = function() {
                if (speechText && speechText.parentNode) {
                    speechText.parentNode.removeChild(speechText);
                }
            };
        }

        return utterance;
    } catch (error) {
        console.error("Error in speech synthesis:", error);
        return null;
    }
}

// Navigation functions
function navigateTo(page) {
    window.location.href = page;
}

// Notification system
function showNotification(message, type = 'success') {
    console.log(`Notification (${type}):`, message);

    const notification = document.getElementById('notification');
    if (!notification) return;

    notification.textContent = message;
    notification.style.backgroundColor = type === 'success' ? '#2ecc71' : '#e74c3c';
    notification.style.display = 'block';

    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// Create a card element (shared across pages)
function createCard(item, cardType = 'activity') {
    const card = document.createElement('div');
    card.className = `${cardType}-card`;
    card.setAttribute('data-id', item.id);
    card.setAttribute('data-name', item.name);

    if (cardType !== 'message') {
        card.setAttribute('draggable', 'true');
    }

    card.style.backgroundColor = item.color || getDefaultCardColor(cardType);

    card.innerHTML = `
        <img src="${item.image}" alt="${item.name}">
        <p>${item.name}</p>
    `;

    // Add text-to-speech on click
    card.addEventListener('click', function() {
        speak(item.name);

        // If this is a communication card, add it to the message
        if (cardType === 'communication') {
            addToMessage(item);
        }
    });

    return card;
}

// Get default color based on card type
function getDefaultCardColor(cardType) {
    const colors = {
        'activity': '#3498db',
        'feeling': '#e74c3c',
        'want': '#9b59b6',
        'communication': '#2ecc71',
        'message': '#f39c12',
        'category': '#1abc9c'
    };

    return colors[cardType] || '#3498db';
}

// Add a word to the message bar (for communication page)
function addToMessage(item) {
    const messageBar = document.getElementById('message-bar');
    if (!messageBar) return;

    const messageCard = document.createElement('div');
    messageCard.className = 'message-card';
    messageCard.setAttribute('data-id', item.id);
    messageCard.setAttribute('data-name', item.name);

    messageCard.innerHTML = `
        <img src="${item.image}" alt="${item.name}" style="width: 30px; height: 30px;">
        <p>${item.name}</p>
        <button class="remove-btn">×</button>
    `;

    // Add delete functionality
    const removeBtn = messageCard.querySelector('.remove-btn');
    if (removeBtn) {
        removeBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            messageCard.remove();
            updateFullMessage();
        });
    }

    // Add click to speak individual word
    messageCard.addEventListener('click', function() {
        speak(item.name);
    });

    messageBar.appendChild(messageCard);
    updateFullMessage();
}

// Update the full message text (for speak button)
function updateFullMessage() {
    const messageBar = document.getElementById('message-bar');
    if (!messageBar) return;

    const fullMessage = Array.from(messageBar.querySelectorAll('.message-card'))
        .map(card => card.getAttribute('data-name'))
        .join(' ');

    const speakButton = document.getElementById('speak-button');
    if (speakButton) {
        if (fullMessage.length > 0) {
            speakButton.removeAttribute('disabled');
        } else {
            speakButton.setAttribute('disabled', 'true');
        }
    }

    return fullMessage;
}

// Clear the entire message
function clearMessage() {
    const messageBar = document.getElementById('message-bar');
    if (!messageBar) return;

    messageBar.innerHTML = '';
    updateFullMessage();

    showNotification('Message cleared');
}

// Speak the entire message
function speakFullMessage() {
    const fullMessage = updateFullMessage();
    if (fullMessage) {
        speak(fullMessage);
    } else {
        showNotification('No message to speak', 'error');
    }
}

// Add typed text to the message
function addTypedText() {
    const textInput = document.getElementById('text-input');
    if (!textInput || !textInput.value.trim()) return;

    // Create a custom item from the typed text
    const customText = textInput.value.trim();
    const customItem = {
        id: 'typed-' + Date.now(),
        name: customText,
        image: 'https://cdn-icons-png.flaticon.com/128/1250/1250615.png', // Keyboard icon
        type: 'typed',
        color: '#7f8c8d'
    };

    // Add to message
    addToMessage(customItem);

    // Clear the input
    textInput.value = '';
    textInput.focus();
}

// Setup keyboard input functionality
function setupKeyboardInput() {
    const keyboardToggle = document.getElementById('toggle-keyboard');
    const textInputArea = document.getElementById('text-input-area');
    const textInput = document.getElementById('text-input');
    const addTextBtn = document.getElementById('add-text-btn');

    if (keyboardToggle && textInputArea && textInput && addTextBtn) {
        keyboardToggle.addEventListener('click', function() {
            // Toggle visibility of text input area
            if (textInputArea.style.display === 'none') {
                textInputArea.style.display = 'flex';
                textInput.focus();
            } else {
                textInputArea.style.display = 'none';
            }
        });

        // Handle adding the typed text
        addTextBtn.addEventListener('click', function() {
            addTypedText();
        });

        // Also add it when pressing Enter
        textInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                addTypedText();
            }
        });
    }
}

// Log that common.js has loaded successfully
console.log("common.js loaded successfully");