// schedule.js - Functionality for the Visual Schedule page

// Default activities
const defaultActivities = [
    { id: 1, name: "Wake Up", image: "https://cdn-icons-png.flaticon.com/128/3094/3094837.png", type: "activity", color: "#3498db" },
    { id: 2, name: "Brush Teeth", image: "https://cdn-icons-png.flaticon.com/128/3588/3588516.png", type: "activity", color: "#3498db" },
    { id: 3, name: "Get Dressed", image: "https://cdn-icons-png.flaticon.com/128/2553/2553691.png", type: "activity", color: "#3498db" },
    { id: 4, name: "Breakfast", image: "https://cdn-icons-png.flaticon.com/128/3480/3480823.png", type: "activity", color: "#3498db" },
    { id: 5, name: "School", image: "https://cdn-icons-png.flaticon.com/128/2602/2602414.png", type: "activity", color: "#3498db" },
    { id: 6, name: "Play Time", image: "https://cdn-icons-png.flaticon.com/128/2790/2790806.png", type: "activity", color: "#3498db" },
    { id: 7, name: "Lunch", image: "https://cdn-icons-png.flaticon.com/128/1046/1046857.png", type: "activity", color: "#3498db" },
    { id: 8, name: "Homework", image: "https://cdn-icons-png.flaticon.com/128/3426/3426544.png", type: "activity", color: "#3498db" },
    { id: 9, name: "Dinner", image: "https://cdn-icons-png.flaticon.com/128/1147/1147805.png", type: "activity", color: "#3498db" },
    { id: 10, name: "Bath", image: "https://cdn-icons-png.flaticon.com/128/900/900757.png", type: "activity", color: "#3498db" },
    { id: 11, name: "Storytime", image: "https://cdn-icons-png.flaticon.com/128/3331/3331879.png", type: "activity", color: "#3498db" },
    { id: 12, name: "Bedtime", image: "https://cdn-icons-png.flaticon.com/128/3094/3094837.png", type: "activity", color: "#3498db" },
    { id: 13, name: "Outdoor Play", image: "https://cdn-icons-png.flaticon.com/128/6680/6680916.png", type: "activity", color: "#3498db" },
    { id: 14, name: "Art Time", image: "https://cdn-icons-png.flaticon.com/128/1165/1165602.png", type: "activity", color: "#3498db" },
    { id: 15, name: "Music Time", image: "https://cdn-icons-png.flaticon.com/128/651/651799.png", type: "activity", color: "#3498db" }
];

// Preset schedules
const defaultPresets = {
    morning: [1, 2, 3, 4, 5],
    afternoon: [6, 7, 8],
    evening: [9, 10, 11, 12]
};

// Active collections
let myActivities = [...defaultActivities];
let presets = {...defaultPresets};

// Initialize the schedule page
function initSchedulePage() {
    // Initialize activity cards
    initActivities();

    // Initialize schedule container with drag-and-drop
    initScheduleContainer();

    // Add event listeners for preset buttons
    setupPresetButtons();
}

// Initialize activity cards
function initActivities() {
    const grid = document.getElementById('activity-grid');
    if (!grid) return;

    grid.innerHTML = '';

    myActivities.forEach(activity => {
        const card = document.createElement('div');
        card.className = 'activity-card';
        card.setAttribute('data-id', activity.id);
        card.setAttribute('draggable', 'true');
        card.style.backgroundColor = activity.color;

        card.innerHTML = `
            <img src="${activity.image}" alt="${activity.name}">
            <p>${activity.name}</p>
        `;

        // Add drag event listeners
        card.addEventListener('dragstart', function(e) {
            e.dataTransfer.setData('text/plain', activity.id);
            this.classList.add('dragging');
        });

        card.addEventListener('dragend', function() {
            this.classList.remove('dragging');
        });

        // Add click for speech
        card.addEventListener('click', function() {
            speak(activity.name);
        });

        grid.appendChild(card);
    });
}

// Initialize schedule container with drag-and-drop
function initScheduleContainer() {
    const container = document.getElementById('schedule-container');
    if (!container) return;

    // Add drop event listeners
    container.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.backgroundColor = '#d6eaf8';
    });

    container.addEventListener('dragleave', function() {
        this.style.backgroundColor = '#ecf0f1';
    });

    container.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.backgroundColor = '#ecf0f1';

        const dataTransfer = e.dataTransfer.getData('text/plain');

        // Check if it's a reordering action
        if (dataTransfer.startsWith('reorder-')) {
            // The card is already in the schedule, don't add a new one
            return;
        }

        const id = parseInt(dataTransfer);

        // Check if we already have 8 items
        if (container.children.length >= 8) {
            showNotification("You can only add up to 8 activities to the schedule!", "error");
            return;
        }

        // Find the activity
        const activity = myActivities.find(a => a.id === id);
        if (activity) {
            addToSchedule(activity);
        }
    });
}

// Add an activity to the schedule
function addToSchedule(activity) {
    const container = document.getElementById('schedule-container');
    if (!container) return;

    const card = document.createElement('div');
    card.className = 'activity-card';
    card.setAttribute('data-id', activity.id);
    card.style.backgroundColor = activity.color;

    card.innerHTML = `
        <img src="${activity.image}" alt="${activity.name}">
        <p>${activity.name}</p>
        <button class="delete-btn">×</button>
    `;

    // Add delete functionality
    card.querySelector('.delete-btn').addEventListener('click', function(e) {
        e.stopPropagation();
        card.remove();
    });

    // Add click to speak and toggle completion
    card.addEventListener('click', function() {
        speak(activity.name);
        this.style.opacity = this.style.opacity === '0.5' ? '1' : '0.5';
    });

    // Make it draggable for reordering
    card.setAttribute('draggable', 'true');

    card.addEventListener('dragstart', function(e) {
        e.dataTransfer.setData('text/plain', 'reorder-' + activity.id);
        this.classList.add('dragging');

        // Store the card being dragged for reordering
        window.draggedCard = this;
    });

    card.addEventListener('dragend', function() {
        this.classList.remove('dragging');
        window.draggedCard = null;

        // Remove any reordering indicators
        document.querySelectorAll('.drag-over-top, .drag-over-bottom').forEach(el => {
            el.classList.remove('drag-over-top');
            el.classList.remove('drag-over-bottom');
        });
    });

    // Add event listeners for reordering
    card.addEventListener('dragover', function(e) {
        e.preventDefault();

        // Only process if we're reordering (not adding new cards)
        if (!window.draggedCard || window.draggedCard === this) {
            return;
        }

        const rect = this.getBoundingClientRect();
        const midY = rect.top + rect.height / 2;

        const container = document.getElementById('schedule-container');

        if (e.clientY < midY) {
            // Insert before this card
            container.insertBefore(window.draggedCard, this);
        } else {
            // Insert after this card
            container.insertBefore(window.draggedCard, this.nextSibling);
        }

        showNotification('Activity reordered!');
    });

    container.appendChild(card);
    speak(activity.name);
}

// Setup preset buttons
function setupPresetButtons() {
    // Morning preset
    document.getElementById('load-morning').addEventListener('click', function() {
        loadPreset('morning');
    });

    // Afternoon preset
    document.getElementById('load-afternoon').addEventListener('click', function() {
        loadPreset('afternoon');
    });

    // Evening preset
    document.getElementById('load-evening').addEventListener('click', function() {
        loadPreset('evening');
    });

    // Save schedule button
    document.getElementById('save-schedule').addEventListener('click', function() {
        saveCurrentSchedule();
    });

    // Clear schedule button
    document.getElementById('clear-schedule').addEventListener('click', function() {
        clearSchedule();
    });
}

// Load a preset schedule
function loadPreset(presetName) {
    const container = document.getElementById('schedule-container');
    if (!container) return;

    container.innerHTML = '';

    if (presets[presetName]) {
        const activityIds = presets[presetName];

        activityIds.forEach(id => {
            const activity = myActivities.find(a => a.id === id);
            if (activity) {
                addToSchedule(activity);
            }
        });

        showNotification(`Loaded ${presetName} schedule`);
    }
}

// Save the current schedule
function saveCurrentSchedule() {
    const scheduledActivities = [];
    const container = document.getElementById('schedule-container');

    if (!container) return;

    container.querySelectorAll('.activity-card').forEach(card => {
        scheduledActivities.push(parseInt(card.getAttribute('data-id')));
    });

    const planName = prompt('Enter a name for this plan:');
    if (planName) {
        presets[planName] = scheduledActivities;
        showNotification(`Plan "${planName}" saved successfully`);
    }
}

// Clear the schedule
function clearSchedule() {
    const container = document.getElementById('schedule-container');
    if (container) {
        container.innerHTML = '';
        showNotification('Schedule cleared');
    }
}

// Initialize the page when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM loaded for schedule page");
    initSchedulePage();
});

// Also initialize if DOM is already loaded
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    console.log("DOM already loaded, initializing schedule page now");
    initSchedulePage();
}.top + rect.height / 2;

        // Clear previous indicators
        this.classList.remove('drag-over-top');
        this.classList.remove('drag-over-bottom');

        // Show drop indicator above or below
        if (e.clientY < midY) {
            this.classList.add('drag-over-top');
        } else {
            this.classList.add('drag-over-bottom');
        }
    });

    card.addEventListener('dragleave', function() {
        this.classList.remove('drag-over-top');
        this.classList.remove('drag-over-bottom');
    });

    card.addEventListener('drop', function(e) {
        e.preventDefault();
        e.stopPropagation();

        this.classList.remove('drag-over-top');
        this.classList.remove('drag-over-bottom');

        // Only process if we're reordering
        if (!window.draggedCard || window.draggedCard === this) {
            return;
        }

        const rect = this.getBoundingClientRect();
        const midY = rect