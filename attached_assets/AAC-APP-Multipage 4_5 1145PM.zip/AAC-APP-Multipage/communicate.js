// communicate.js - Functionality for the AAC communication page

// Debug the speech functionality
console.log("Communicate page loading...");

// Direct implementation of speech synthesis
function directSpeak(text) {
    console.log("Direct speak function called with:", text);

    if (!('speechSynthesis' in window)) {
        console.error("Speech synthesis not available in this browser");
        return null;
    }

    try {
        // Cancel any ongoing speech
        window.speechSynthesis.cancel();

        // Create a new speech utterance
        const utterance = new SpeechSynthesisUtterance(text);

        // Use default settings
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;

        // Speak the text
        window.speechSynthesis.speak(utterance);

        return utterance;
    } catch (error) {
        console.error("Error in direct speech synthesis:", error);
        return null;
    }
}

// Override createCard function for communication page
function createCommunicationCard(item) {
    const card = document.createElement('div');
    card.className = `communication-card word-${item.type}`;
    card.setAttribute('data-id', item.id);
    card.setAttribute('data-name', item.name);
    card.style.backgroundColor = item.color;

    card.innerHTML = `
        <img src="${item.image}" alt="${item.name}">
        <p>${item.name}</p>
    `;

    // Add direct click handler for speech
    card.addEventListener('click', function(e) {
        console.log("Communication card clicked:", item.name);

        // Speak the word
        if (typeof window.speak === 'function') {
            window.speak(item.name);
        } else {
            directSpeak(item.name);
        }

        // Add to message
        addToMessage(item);
    });

    return card;
}

// Fix for the Speak Message button functionality
function setupSpeakMessageButton() {
    const speakButton = document.getElementById('speak-button');
    if (speakButton) {
        speakButton.addEventListener('click', function() {
            const messageBar = document.getElementById('message-bar');
            if (!messageBar) return;

            const fullMessage = Array.from(messageBar.querySelectorAll('.message-card'))
                .map(card => card.getAttribute('data-name'))
                .join(' ');

            if (fullMessage) {
                console.log("Speaking full message:", fullMessage);

                // Try global function first, fall back to direct implementation
                if (typeof window.speak === 'function') {
                    window.speak(fullMessage);
                } else {
                    directSpeak(fullMessage);
                }
            }
        });
    }
}

// Vocabulary data structure
const vocabularyData = {
    // Core vocabulary (always visible)
    core: [
        // Pronouns (yellow) - 2 columns
        { id: 1001, name: "I", image: "https://cdn-icons-png.flaticon.com/128/1946/1946429.png", type: "pronouns", color: "#f1c40f" },
        { id: 1002, name: "You", image: "https://cdn-icons-png.flaticon.com/128/1077/1077114.png", type: "pronouns", color: "#f1c40f" },
        { id: 1003, name: "He", image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png", type: "pronouns", color: "#f1c40f" },
        { id: 1004, name: "She", image: "https://cdn-icons-png.flaticon.com/128/3135/3135789.png", type: "pronouns", color: "#f1c40f" },
        { id: 1005, name: "We", image: "https://cdn-icons-png.flaticon.com/128/476/476863.png", type: "pronouns", color: "#f1c40f" },
        { id: 1006, name: "Let's", image: "https://cdn-icons-png.flaticon.com/128/9137/9137136.png", type: "pronouns", color: "#f1c40f" },
        { id: 1007, name: "Me", image: "https://cdn-icons-png.flaticon.com/128/1946/1946429.png", type: "pronouns", color: "#f1c40f" },
        { id: 1008, name: "My", image: "https://cdn-icons-png.flaticon.com/128/3208/3208723.png", type: "pronouns", color: "#f1c40f" },

        // Column 2 of pronouns
        { id: 1009, name: "Your", image: "https://cdn-icons-png.flaticon.com/128/3208/3208723.png", type: "pronouns", color: "#f1c40f" },
        { id: 1010, name: "", image: "", type: "pronouns", color: "#f1c40f" }, // Empty placeholder
        { id: 1011, name: "", image: "", type: "pronouns", color: "#f1c40f" }, // Empty placeholder
        { id: 1012, name: "", image: "", type: "pronouns", color: "#f1c40f" }, // Empty placeholder

        // Actions (blue) - 2 columns
        { id: 1013, name: "Go", image: "https://cdn-icons-png.flaticon.com/128/3097/3097160.png", type: "actions", color: "#3498db" },
        { id: 1014, name: "Talk", image: "https://cdn-icons-png.flaticon.com/128/2665/2665632.png", type: "actions", color: "#3498db" },
        { id: 1015, name: "See", image: "https://cdn-icons-png.flaticon.com/128/1068/1068770.png", type: "actions", color: "#3498db" },
        { id: 1016, name: "Watch", image: "https://cdn-icons-png.flaticon.com/128/2548/2548351.png", type: "actions", color: "#3498db" },

        // Column 2 of actions
        { id: 1017, name: "Wait", image: "https://cdn-icons-png.flaticon.com/128/6708/6708938.png", type: "actions", color: "#3498db" },
        { id: 1018, name: "Help", image: "https://cdn-icons-png.flaticon.com/128/1662/1662341.png", type: "actions", color: "#3498db" },
        { id: 1019, name: "Put", image: "https://cdn-icons-png.flaticon.com/128/3695/3695580.png", type: "actions", color: "#3498db" },
        { id: 1020, name: "Make", image: "https://cdn-icons-png.flaticon.com/128/5694/5694749.png", type: "actions", color: "#3498db" },

        // Fillers (teal) - 2 columns
        { id: 1021, name: "And", image: "https://cdn-icons-png.flaticon.com/128/3898/3898126.png", type: "fillers", color: "#1abc9c" },
        { id: 1022, name: "For", image: "https://cdn-icons-png.flaticon.com/128/3413/3413537.png", type: "fillers", color: "#1abc9c" },
        { id: 1023, name: "Is", image: "https://cdn-icons-png.flaticon.com/128/0/375.png", type: "fillers", color: "#1abc9c" },
        { id: 1024, name: "To", image: "https://cdn-icons-png.flaticon.com/128/7641/7641727.png", type: "fillers", color: "#1abc9c" },

        // Column 2 of fillers
        { id: 1025, name: "Was", image: "https://cdn-icons-png.flaticon.com/128/2619/2619285.png", type: "fillers", color: "#1abc9c" },
        { id: 1026, name: "With", image: "https://cdn-icons-png.flaticon.com/128/5636/5636567.png", type: "fillers", color: "#1abc9c" },
        { id: 1027, name: "It", image: "https://cdn-icons-png.flaticon.com/128/2438/2438006.png", type: "fillers", color: "#1abc9c" },
        { id: 1028, name: "That", image: "https://cdn-icons-png.flaticon.com/128/9149/9149046.png", type: "fillers", color: "#1abc9c" },

        // Descriptors (purple) - 2 columns
        { id: 1029, name: "Like", image: "https://cdn-icons-png.flaticon.com/128/739/739231.png", type: "descriptors", color: "#9b59b6" },
        { id: 1030, name: "Need", image: "https://cdn-icons-png.flaticon.com/128/3997/3997872.png", type: "descriptors", color: "#9b59b6" },
        { id: 1031, name: "Want", image: "https://cdn-icons-png.flaticon.com/128/3997/3997872.png", type: "descriptors", color: "#9b59b6" },
        { id: 1032, name: "Looking for", image: "https://cdn-icons-png.flaticon.com/128/1086/1086933.png", type: "descriptors", color: "#9b59b6" },

        // Column 2 of descriptors
        { id: 1033, name: "Don't", image: "https://cdn-icons-png.flaticon.com/128/5290/5290057.png", type: "descriptors", color: "#9b59b6" },
        { id: 1034, name: "Stop", image: "https://cdn-icons-png.flaticon.com/128/1634/1634158.png", type: "descriptors", color: "#9b59b6" },
        { id: 1035, name: "More", image: "https://cdn-icons-png.flaticon.com/128/748/748113.png", type: "descriptors", color: "#9b59b6" },
        { id: 1036, name: "Please", image: "https://cdn-icons-png.flaticon.com/128/4473/4473293.png", type: "descriptors", color: "#9b59b6" },

        // Questions (red) - 2 columns
        { id: 1037, name: "Who", image: "https://cdn-icons-png.flaticon.com/128/686/686317.png", type: "questions", color: "#e74c3c" },
        { id: 1038, name: "What", image: "https://cdn-icons-png.flaticon.com/128/471/471664.png", type: "questions", color: "#e74c3c" },
        { id: 1039, name: "Where", image: "https://cdn-icons-png.flaticon.com/128/684/684908.png", type: "questions", color: "#e74c3c" },
        { id: 1040, name: "When", image: "https://cdn-icons-png.flaticon.com/128/2972/2972531.png", type: "questions", color: "#e74c3c" },

        // Column 2 of questions
        { id: 1041, name: "Why", image: "https://cdn-icons-png.flaticon.com/128/2476/2476190.png", type: "questions", color: "#e74c3c" },
        { id: 1042, name: "How", image: "https://cdn-icons-png.flaticon.com/128/5246/5246877.png", type: "questions", color: "#e74c3c" },
        { id: 1043, name: "Which", image: "https://cdn-icons-png.flaticon.com/128/5742/5742546.png", type: "questions", color: "#e74c3c" },
        { id: 1044, name: "Can I", image: "https://cdn-icons-png.flaticon.com/128/3229/3229134.png", type: "questions", color: "#e74c3c" },

        // Places (green) - 1 column
        { id: 1045, name: "Home", image: "https://cdn-icons-png.flaticon.com/128/1670/1670080.png", type: "places", color: "#27ae60" },
        { id: 1046, name: "School", image: "https://cdn-icons-png.flaticon.com/128/2602/2602414.png", type: "places", color: "#27ae60" },
        { id: 1047, name: "Doctor's", image: "https://cdn-icons-png.flaticon.com/128/2786/2786194.png", type: "places", color: "#27ae60" },
        { id: 1048, name: "Outside", image: "https://cdn-icons-png.flaticon.com/128/1329/1329016.png", type: "places", color: "#27ae60" },

        // Objects (orange) - 1 column
        { id: 1049, name: "Headphones", image: "https://cdn-icons-png.flaticon.com/128/3578/3578440.png", type: "objects", color: "#f39c12" },
        { id: 1050, name: "Bunny", image: "https://cdn-icons-png.flaticon.com/128/375/375073.png", type: "objects", color: "#f39c12" },
        { id: 1051, name: "iPad", image: "https://cdn-icons-png.flaticon.com/128/821/821749.png", type: "objects", color: "#f39c12" },
        { id: 1052, name: "Toy", image: "https://cdn-icons-png.flaticon.com/128/3081/3081993.png", type: "objects", color: "#f39c12" }
    ],

    // Categories definitions
    categories: [
        { id: 2001, name: "Pronouns", category: "pronouns", image: "https://cdn-icons-png.flaticon.com/128/1946/1946429.png", color: "#f1c40f" },
        { id: 2002, name: "People", category: "people", image: "https://cdn-icons-png.flaticon.com/128/476/476863.png", color: "#e67e22" },
        { id: 2003, name: "Actions", category: "actions", image: "https://cdn-icons-png.flaticon.com/128/3097/3097160.png", color: "#3498db" },
        { id: 2004, name: "Feelings", category: "feelings", image: "https://cdn-icons-png.flaticon.com/128/742/742751.png", color: "#e74c3c" },
        { id: 2005, name: "Describe", category: "adjectives", image: "https://cdn-icons-png.flaticon.com/128/3731/3731619.png", color: "#2ecc71" },
        { id: 2006, name: "Questions", category: "questions", image: "https://cdn-icons-png.flaticon.com/128/471/471664.png", color: "#9b59b6" },
        { id: 2007, name: "Places", category: "places", image: "https://cdn-icons-png.flaticon.com/128/684/684908.png", color: "#27ae60" },
        { id: 2008, name: "Food", category: "food", image: "https://cdn-icons-png.flaticon.com/128/3132/3132693.png", color: "#d35400" },
        { id: 2009, name: "Time", category: "time", image: "https://cdn-icons-png.flaticon.com/128/2972/2972531.png", color: "#f39c12" },
        { id: 2010, name: "Activities", category: "activities", image: "https://cdn-icons-png.flaticon.com/128/2790/2790806.png", color: "#8e44ad" }
    ],

    // Fringe vocabulary organized by category
    fringe: {
        "actions": [
            { id: 3201, name: "Sleep", image: "https://cdn-icons-png.flaticon.com/128/8139/8139752.png", category: "actions", color: "#3498db" },
            { id: 3202, name: "Read", image: "https://cdn-icons-png.flaticon.com/128/3426/3426543.png", category: "actions", color: "#3498db" },
            { id: 3203, name: "Watch TV", image: "https://cdn-icons-png.flaticon.com/128/2982/2982606.png", category: "actions", color: "#3498db" },
            { id: 3204, name: "Help", image: "https://cdn-icons-png.flaticon.com/128/1662/1662341.png", category: "actions", color: "#3498db" },
            { id: 3205, name: "Draw", image: "https://cdn-icons-png.flaticon.com/128/3209/3209175.png", category: "actions", color: "#3498db" },
            { id: 3206, name: "Sing", image: "https://cdn-icons-png.flaticon.com/128/2588/2588585.png", category: "actions", color: "#3498db" },
            { id: 3207, name: "Dance", image: "https://cdn-icons-png.flaticon.com/128/2548/2548378.png", category: "actions", color: "#3498db" },
            { id: 3208, name: "Swim", image: "https://cdn-icons-png.flaticon.com/128/2204/2204459.png", category: "actions", color: "#3498db" },
            { id: 3209, name: "Jump", image: "https://cdn-icons-png.flaticon.com/128/2574/2574018.png", category: "actions", color: "#3498db" },
            { id: 3210, name: "Run", image: "https://cdn-icons-png.flaticon.com/128/384/384809.png", category: "actions", color: "#3498db" }
        ],
        "feelings": [
            { id: 3301, name: "Angry", image: "https://cdn-icons-png.flaticon.com/128/742/742744.png", category: "feelings", color: "#e74c3c" },
            { id: 3302, name: "Excited", image: "https://cdn-icons-png.flaticon.com/128/742/742745.png", category: "feelings", color: "#e74c3c" },
            { id: 3303, name: "Tired", image: "https://cdn-icons-png.flaticon.com/128/742/742784.png", category: "feelings", color: "#e74c3c" },
            { id: 3304, name: "Scared", image: "https://cdn-icons-png.flaticon.com/128/742/742753.png", category: "feelings", color: "#e74c3c" },
            { id: 3305, name: "Bored", image: "https://cdn-icons-png.flaticon.com/128/742/742770.png", category: "feelings", color: "#e74c3c" },
            { id: 3306, name: "Hungry", image: "https://cdn-icons-png.flaticon.com/128/1791/1791341.png", category: "feelings", color: "#e74c3c" },
            { id: 3307, name: "Thirsty", image: "https://cdn-icons-png.flaticon.com/128/3106/3106408.png", category: "feelings", color: "#e74c3c" },
            { id: 3308, name: "Sick", image: "https://cdn-icons-png.flaticon.com/128/2659/2659806.png", category: "feelings", color: "#e74c3c" }
        ],
        "adjectives": [
            { id: 3401, name: "Big", image: "https://cdn-icons-png.flaticon.com/128/1388/1388902.png", category: "adjectives", color: "#2ecc71" },
            { id: 3402, name: "Small", image: "https://cdn-icons-png.flaticon.com/128/1388/1388887.png", category: "adjectives", color: "#2ecc71" },
            { id: 3403, name: "Hot", image: "https://cdn-icons-png.flaticon.com/128/2427/2427982.png", category: "adjectives", color: "#2ecc71" },
            { id: 3404, name: "Cold", image: "https://cdn-icons-png.flaticon.com/128/3050/3050379.png", category: "adjectives", color: "#2ecc71" },
            { id: 3405, name: "Good", image: "https://cdn-icons-png.flaticon.com/128/4575/4575389.png", category: "adjectives", color: "#2ecc71" },
            { id: 3406, name: "Bad", image: "https://cdn-icons-png.flaticon.com/128/4575/4575452.png", category: "adjectives", color: "#2ecc71" },
            { id: 3407, name: "Fast", image: "https://cdn-icons-png.flaticon.com/128/2082/2082003.png", category: "adjectives", color: "#2ecc71" },
            { id: 3408, name: "Slow", image: "https://cdn-icons-png.flaticon.com/128/3997/3997523.png", category: "adjectives", color: "#2ecc71" },
            { id: 3409, name: "Hard", image: "https://cdn-icons-png.flaticon.com/128/1491/1491144.png", category: "adjectives", color: "#2ecc71" },
            { id: 3410, name: "Soft", image: "https://cdn-icons-png.flaticon.com/128/1249/1249390.png", category: "adjectives", color: "#2ecc71" }
        ],
        "negatives": [
            { id: 3501, name: "Don't", image: "https://cdn-icons-png.flaticon.com/128/5290/5290057.png", category: "negatives", color: "#c0392b" },
            { id: 3502, name: "Not", image: "https://cdn-icons-png.flaticon.com/128/5290/5290057.png", category: "negatives", color: "#c0392b" },
            { id: 3503, name: "Can't", image: "https://cdn-icons-png.flaticon.com/128/5290/5290084.png", category: "negatives", color: "#c0392b" },
            { id: 3504, name: "Won't", image: "https://cdn-icons-png.flaticon.com/128/5290/5290057.png", category: "negatives", color: "#c0392b" },
            { id: 3505, name: "Didn't", image: "https://cdn-icons-png.flaticon.com/128/5290/5290057.png", category: "negatives", color: "#c0392b" },
            { id: 3506, name: "Never", image: "https://cdn-icons-png.flaticon.com/128/5290/5290084.png", category: "negatives", color: "#c0392b" }
        ],
        "questions": [
            { id: 3601, name: "What", image: "https://cdn-icons-png.flaticon.com/128/471/471664.png", category: "questions", color: "#9b59b6" },
            { id: 3602, name: "Where", image: "https://cdn-icons-png.flaticon.com/128/684/684908.png", category: "questions", color: "#9b59b6" },
            { id: 3603, name: "When", image: "https://cdn-icons-png.flaticon.com/128/2972/2972531.png", category: "questions", color: "#9b59b6" },
            { id: 3604, name: "Why", image: "https://cdn-icons-png.flaticon.com/128/2476/2476190.png", category: "questions", color: "#9b59b6" },
            { id: 3605, name: "Who", image: "https://cdn-icons-png.flaticon.com/128/686/686317.png", category: "questions", color: "#9b59b6" },
            { id: 3606, name: "How", image: "https://cdn-icons-png.flaticon.com/128/5246/5246877.png", category: "questions", color: "#9b59b6" }
        ],
        "social": [
            { id: 3701, name: "Hello", image: "https://cdn-icons-png.flaticon.com/128/7128/7128853.png", category: "social", color: "#16a085" },
            { id: 3702, name: "Goodbye", image: "https://cdn-icons-png.flaticon.com/128/1388/1388929.png", category: "social", color: "#16a085" },
            { id: 3703, name: "Please", image: "https://cdn-icons-png.flaticon.com/128/4473/4473293.png", category: "social", color: "#16a085" },
            { id: 3704, name: "Excuse me", image: "https://cdn-icons-png.flaticon.com/128/3064/3064155.png", category: "social", color: "#16a085" },
            { id: 3705, name: "Hi", image: "https://cdn-icons-png.flaticon.com/128/6698/6698121.png", category: "social", color: "#16a085" }
        ],
        "time": [
            { id: 3801, name: "Now", image: "https://cdn-icons-png.flaticon.com/128/2972/2972531.png", category: "time", color: "#f39c12" },
            { id: 3802, name: "Later", image: "https://cdn-icons-png.flaticon.com/128/3014/3014289.png", category: "time", color: "#f39c12" },
            { id: 3803, name: "First", image: "https://cdn-icons-png.flaticon.com/128/2666/2666505.png", category: "time", color: "#f39c12" },
            { id: 3804, name: "Next", image: "https://cdn-icons-png.flaticon.com/128/4375/4375446.png", category: "time", color: "#f39c12" },
            { id: 3805, name: "Before", image: "https://cdn-icons-png.flaticon.com/128/3908/3908492.png", category: "time", color: "#f39c12" },
            { id: 3806, name: "After", image: "https://cdn-icons-png.flaticon.com/128/3908/3908495.png", category: "time", color: "#f39c12" },
            { id: 3807, name: "Today", image: "https://cdn-icons-png.flaticon.com/128/2278/2278049.png", category: "time", color: "#f39c12" },
            { id: 3808, name: "Tomorrow", image: "https://cdn-icons-png.flaticon.com/128/4289/4289464.png", category: "time", color: "#f39c12" },
            { id: 3809, name: "Yesterday", image: "https://cdn-icons-png.flaticon.com/128/4289/4289464.png", category: "time", color: "#f39c12" }
        ],
        "places": [
            { id: 3901, name: "Home", image: "https://cdn-icons-png.flaticon.com/128/1670/1670080.png", category: "places", color: "#27ae60" },
            { id: 3902, name: "School", image: "https://cdn-icons-png.flaticon.com/128/2602/2602414.png", category: "places", color: "#27ae60" },
            { id: 3903, name: "Bathroom", image: "https://cdn-icons-png.flaticon.com/128/2452/2452300.png", category: "places", color: "#27ae60" },
            { id: 3904, name: "Bedroom", image: "https://cdn-icons-png.flaticon.com/128/3030/3030336.png", category: "places", color: "#27ae60" },
            { id: 3905, name: "Kitchen", image: "https://cdn-icons-png.flaticon.com/128/1724/1724545.png", category: "places", color: "#27ae60" },
            { id: 3906, name: "Store", image: "https://cdn-icons-png.flaticon.com/128/2331/2331966.png", category: "places", color: "#27ae60" },
            { id: 3907, name: "Playground", image: "https://cdn-icons-png.flaticon.com/128/6680/6680916.png", category: "places", color: "#27ae60" },
            { id: 3908, name: "Outside", image: "https://cdn-icons-png.flaticon.com/128/1329/1329016.png", category: "places", color: "#27ae60" },
            { id: 3909, name: "Restaurant", image: "https://cdn-icons-png.flaticon.com/128/562/562678.png", category: "places", color: "#27ae60" },
            { id: 3910, name: "Doctor", image: "https://cdn-icons-png.flaticon.com/128/2786/2786194.png", category: "places", color: "#27ae60" }
        ],
        "food": [
            { id: 4001, name: "Water", image: "https://cdn-icons-png.flaticon.com/128/3248/3248369.png", category: "food", color: "#d35400" },
            { id: 4002, name: "Juice", image: "https://cdn-icons-png.flaticon.com/128/3050/3050540.png", category: "food", color: "#d35400" },
            { id: 4003, name: "Milk", image: "https://cdn-icons-png.flaticon.com/128/1699/1699231.png", category: "food", color: "#d35400" },
                        { id: 4004, name: "Apple", image: "https://cdn-icons-png.flaticon.com/128/415/415682.png", category: "food", color: "#d35400" },
                        { id: 4005, name: "Banana", image: "https://cdn-icons-png.flaticon.com/128/2909/2909761.png", category: "food", color: "#d35400" },
                        { id: 4006, name: "Sandwich", image: "https://cdn-icons-png.flaticon.com/128/783/783248.png", category: "food", color: "#d35400" },
                        { id: 4007, name: "Pizza", image: "https://cdn-icons-png.flaticon.com/128/3132/3132702.png", category: "food", color: "#d35400" },
                        { id: 4008, name: "Chicken", image: "https://cdn-icons-png.flaticon.com/128/1046/1046769.png", category: "food", color: "#d35400" },
                        { id: 4009, name: "Cookies", image: "https://cdn-icons-png.flaticon.com/128/541/541732.png", category: "food", color: "#d35400" },
                        { id: 4010, name: "Ice Cream", image: "https://cdn-icons-png.flaticon.com/128/938/938063.png", category: "food", color: "#d35400" }
                    ],
                    "objects": [
                        { id: 4101, name: "Toy", image: "https://cdn-icons-png.flaticon.com/128/3081/3081993.png", category: "objects", color: "#2980b9" },
                        { id: 4102, name: "Book", image: "https://cdn-icons-png.flaticon.com/128/2436/2436882.png", category: "objects", color: "#2980b9" },
                        { id: 4103, name: "Phone", image: "https://cdn-icons-png.flaticon.com/128/254/254554.png", category: "objects", color: "#2980b9" },
                        { id: 4104, name: "Tablet", image: "https://cdn-icons-png.flaticon.com/128/821/821749.png", category: "objects", color: "#2980b9" },
                        { id: 4105, name: "Pencil", image: "https://cdn-icons-png.flaticon.com/128/3094/3094918.png", category: "objects", color: "#2980b9" },
                        { id: 4106, name: "Chair", image: "https://cdn-icons-png.flaticon.com/128/5899/5899027.png", category: "objects", color: "#2980b9" },
                        { id: 4107, name: "Table", image: "https://cdn-icons-png.flaticon.com/128/1012/1012312.png", category: "objects", color: "#2980b9" },
                        { id: 4108, name: "TV", image: "https://cdn-icons-png.flaticon.com/128/2982/2982606.png", category: "objects", color: "#2980b9" },
                        { id: 4109, name: "Car", image: "https://cdn-icons-png.flaticon.com/128/2076/2076810.png", category: "objects", color: "#2980b9" },
                        { id: 4110, name: "Light", image: "https://cdn-icons-png.flaticon.com/128/702/702814.png", category: "objects", color: "#2980b9" }
                    ],
                    "activities": [
                        { id: 4201, name: "Play", image: "https://cdn-icons-png.flaticon.com/128/2790/2790806.png", category: "activities", color: "#8e44ad" },
                        { id: 4202, name: "Read", image: "https://cdn-icons-png.flaticon.com/128/3426/3426543.png", category: "activities", color: "#8e44ad" },
                        { id: 4203, name: "Draw", image: "https://cdn-icons-png.flaticon.com/128/3209/3209175.png", category: "activities", color: "#8e44ad" },
                        { id: 4204, name: "Sing", image: "https://cdn-icons-png.flaticon.com/128/2588/2588585.png", category: "activities", color: "#8e44ad" },
                        { id: 4205, name: "Dance", image: "https://cdn-icons-png.flaticon.com/128/2548/2548378.png", category: "activities", color: "#8e44ad" },
                        { id: 4206, name: "Watch TV", image: "https://cdn-icons-png.flaticon.com/128/2982/2982606.png", category: "activities", color: "#8e44ad" },
                        { id: 4207, name: "Sleep", image: "https://cdn-icons-png.flaticon.com/128/8139/8139752.png", category: "activities", color: "#8e44ad" },
                        { id: 4208, name: "Jump", image: "https://cdn-icons-png.flaticon.com/128/2574/2574018.png", category: "activities", color: "#8e44ad" },
                        { id: 4209, name: "Run", image: "https://cdn-icons-png.flaticon.com/128/384/384809.png", category: "activities", color: "#8e44ad" },
                        { id: 4210, name: "Swim", image: "https://cdn-icons-png.flaticon.com/128/2204/2204459.png", category: "activities", color: "#8e44ad" }
                    ],
                    "pronouns": [
                        { id: 5001, name: "I", image: "https://cdn-icons-png.flaticon.com/128/1946/1946429.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5002, name: "You", image: "https://cdn-icons-png.flaticon.com/128/1077/1077114.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5003, name: "He", image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5004, name: "She", image: "https://cdn-icons-png.flaticon.com/128/3135/3135789.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5005, name: "We", image: "https://cdn-icons-png.flaticon.com/128/476/476863.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5006, name: "They", image: "https://cdn-icons-png.flaticon.com/128/1390/1390704.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5007, name: "Me", image: "https://cdn-icons-png.flaticon.com/128/1946/1946429.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5008, name: "My", image: "https://cdn-icons-png.flaticon.com/128/3208/3208723.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5009, name: "Your", image: "https://cdn-icons-png.flaticon.com/128/3208/3208723.png", category: "pronouns", color: "#f1c40f" },
                        { id: 5010, name: "Their", image: "https://cdn-icons-png.flaticon.com/128/1390/1390704.png", category: "pronouns", color: "#f1c40f" }
                    ],
                    "people": [
                        { id: 5101, name: "Mom", image: "https://cdn-icons-png.flaticon.com/128/3061/3061341.png", category: "people", color: "#e67e22" },
                        { id: 5102, name: "Dad", image: "https://cdn-icons-png.flaticon.com/128/1665/1665589.png", category: "people", color: "#e67e22" },
                        { id: 5103, name: "Brother", image: "https://cdn-icons-png.flaticon.com/128/2348/2348811.png", category: "people", color: "#e67e22" },
                        { id: 5104, name: "Sister", image: "https://cdn-icons-png.flaticon.com/128/2026/2026518.png", category: "people", color: "#e67e22" },
                        { id: 5105, name: "Teacher", image: "https://cdn-icons-png.flaticon.com/128/609/609651.png", category: "people", color: "#e67e22" },
                        { id: 5106, name: "Friend", image: "https://cdn-icons-png.flaticon.com/128/3166/3166388.png", category: "people", color: "#e67e22" },
                        { id: 5107, name: "Doctor", image: "https://cdn-icons-png.flaticon.com/128/607/607414.png", category: "people", color: "#e67e22" },
                        { id: 5108, name: "Grandma", image: "https://cdn-icons-png.flaticon.com/128/3667/3667283.png", category: "people", color: "#e67e22" },
                        { id: 5109, name: "Grandpa", image: "https://cdn-icons-png.flaticon.com/128/3667/3667249.png", category: "people", color: "#e67e22" }
                    ]
                }
            };

            // Current active category
            let activeCategory = null;

            // Initialize the communication page
            function initCommunicatePage() {
                console.log("Initializing communicate page...");

                // Load core vocabulary with direct speech capability
                initCoreVocabulary();

                // Load categories
                initCategories();

                // Set default fringe vocabulary (can be any category)
                showFringeVocabulary('pronouns');

                // Setup direct speech for the speak message button
                setupSpeakMessageButton();

                // Setup keyboard input
                setupKeyboardInput();

                // Test speech synthesis
                setTimeout(function() {
                    console.log("Testing speech synthesis...");
                    try {
                        directSpeak("");  // Silent test to ensure speech API is initialized
                    } catch (e) {
                        console.error("Speech test failed:", e);
                    }
                }, 1000);

                console.log("Communicate page initialization complete");
            }

            // Initialize the core vocabulary section
// Replace the core vocabulary initialization in communicate.js with this version
// Initialize the core vocabulary section
function initCoreVocabulary() {
    console.log("Initializing core vocabulary with vertical column layout...");
    const coreGrid = document.getElementById('core-grid');
    if (!coreGrid) {
        console.error("Could not find core-grid element!");
        return;
    }

    // Clear the grid
    coreGrid.innerHTML = '';

    // Define the grid structure: 10 columns, 4 rows
    // Each column will be filled top to bottom
    const columnGroups = [
        // First 2 columns (0-1): Pronouns (yellow)
        { type: "pronouns", color: "#f1c40f", columns: [0, 1] },
        // Next 2 columns (2-3): Actions (blue)
        { type: "actions", color: "#3498db", columns: [2, 3] },
        // Next 2 columns (4-5): Fillers (teal)
        { type: "fillers", color: "#1abc9c", columns: [4, 5] },
        // Next 2 columns (6-7): Descriptors (purple)
        { type: "descriptors", color: "#9b59b6", columns: [6, 7] },
        // Next column (8): Places (green)
        { type: "places", color: "#27ae60", columns: [8] },
        // Last column (9): Objects (orange)
        { type: "objects", color: "#f39c12", columns: [9] }
    ];

    // Create a 10x4 grid of empty cells
    const gridCells = Array(10).fill().map(() => Array(4).fill(null));

    // Create vocabulary items and place them in the correct cells
    const words = {
        // Pronouns (yellow) - 2 columns
        pronouns: [
            // Column 1
            { id: 1001, name: "I", image: "https://cdn-icons-png.flaticon.com/128/1946/1946429.png" },
            { id: 1002, name: "You", image: "https://cdn-icons-png.flaticon.com/128/1077/1077114.png" },
            { id: 1003, name: "He", image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png" },
            { id: 1004, name: "She", image: "https://cdn-icons-png.flaticon.com/128/3135/3135789.png" },
            // Column 2
            { id: 1005, name: "We", image: "https://cdn-icons-png.flaticon.com/128/476/476863.png" },
            { id: 1006, name: "Let's", image: "https://cdn-icons-png.flaticon.com/128/9137/9137136.png" },
            { id: 1007, name: "Me", image: "https://cdn-icons-png.flaticon.com/128/1946/1946429.png" },
            { id: 1008, name: "My", image: "https://cdn-icons-png.flaticon.com/128/3208/3208723.png" },
            { id: 1009, name: "Your", image: "https://cdn-icons-png.flaticon.com/128/3208/3208723.png" }
        ],

        // Actions (blue) - 2 columns
        actions: [
            // Column 1
            { id: 1013, name: "Go", image: "https://cdn-icons-png.flaticon.com/128/3097/3097160.png" },
            { id: 1014, name: "Talk", image: "https://cdn-icons-png.flaticon.com/128/2665/2665632.png" },
            { id: 1015, name: "See", image: "https://cdn-icons-png.flaticon.com/128/1068/1068770.png" },
            { id: 1016, name: "Watch", image: "https://cdn-icons-png.flaticon.com/128/2548/2548351.png" },
            // Column 2
            { id: 1017, name: "Wait", image: "https://cdn-icons-png.flaticon.com/128/6708/6708938.png" },
            { id: 1018, name: "Help", image: "https://cdn-icons-png.flaticon.com/128/1662/1662341.png" },
            { id: 1019, name: "Put", image: "https://cdn-icons-png.flaticon.com/128/3695/3695580.png" },
            { id: 1020, name: "Make", image: "https://cdn-icons-png.flaticon.com/128/5694/5694749.png" }
        ],

        // Fillers (teal) - 2 columns
        fillers: [
            // Column 1
            { id: 1021, name: "And", image: "https://cdn-icons-png.flaticon.com/128/3898/3898126.png" },
            { id: 1022, name: "For", image: "https://cdn-icons-png.flaticon.com/128/3413/3413537.png" },
            { id: 1023, name: "Is", image: "https://cdn-icons-png.flaticon.com/128/0/375.png" },
            { id: 1024, name: "To", image: "https://cdn-icons-png.flaticon.com/128/7641/7641727.png" },
            // Column 2
            { id: 1025, name: "Was", image: "https://cdn-icons-png.flaticon.com/128/2619/2619285.png" },
            { id: 1026, name: "With", image: "https://cdn-icons-png.flaticon.com/128/5636/5636567.png" },
            { id: 1027, name: "It", image: "https://cdn-icons-png.flaticon.com/128/2438/2438006.png" },
            { id: 1028, name: "That", image: "https://cdn-icons-png.flaticon.com/128/9149/9149046.png" }
        ],

        // Descriptors (purple) - 2 columns
        descriptors: [
            // Column 1
            { id: 1029, name: "Like", image: "https://cdn-icons-png.flaticon.com/128/739/739231.png" },
            { id: 1030, name: "Need", image: "https://cdn-icons-png.flaticon.com/128/3997/3997872.png" },
            { id: 1031, name: "Want", image: "https://cdn-icons-png.flaticon.com/128/3997/3997872.png" },
            { id: 1032, name: "Looking for", image: "https://cdn-icons-png.flaticon.com/128/1086/1086933.png" },
            // Column 2
            { id: 1033, name: "Don't", image: "https://cdn-icons-png.flaticon.com/128/5290/5290057.png" },
            { id: 1034, name: "Stop", image: "https://cdn-icons-png.flaticon.com/128/1634/1634158.png" },
            { id: 1035, name: "More", image: "https://cdn-icons-png.flaticon.com/128/748/748113.png" },
            { id: 1036, name: "Please", image: "https://cdn-icons-png.flaticon.com/128/4473/4473293.png" }
        ],

        // Questions (red) - 2 columns
        questions: [
            // Column 1
            { id: 1037, name: "Who", image: "https://cdn-icons-png.flaticon.com/128/686/686317.png" },
            { id: 1038, name: "What", image: "https://cdn-icons-png.flaticon.com/128/471/471664.png" },
            { id: 1039, name: "Where", image: "https://cdn-icons-png.flaticon.com/128/684/684908.png" },
            { id: 1040, name: "When", image: "https://cdn-icons-png.flaticon.com/128/2972/2972531.png" },
            // Column 2
            { id: 1041, name: "Why", image: "https://cdn-icons-png.flaticon.com/128/2476/2476190.png" },
            { id: 1042, name: "How", image: "https://cdn-icons-png.flaticon.com/128/5246/5246877.png" },
            { id: 1043, name: "Which", image: "https://cdn-icons-png.flaticon.com/128/5742/5742546.png" },
            { id: 1044, name: "Can I", image: "https://cdn-icons-png.flaticon.com/128/3229/3229134.png" }
        ],

        // Places (green) - 1 column
        places: [
            { id: 1045, name: "Home", image: "https://cdn-icons-png.flaticon.com/128/1670/1670080.png" },
            { id: 1046, name: "School", image: "https://cdn-icons-png.flaticon.com/128/2602/2602414.png" },
            { id: 1047, name: "Doctor's", image: "https://cdn-icons-png.flaticon.com/128/2786/2786194.png" },
            { id: 1048, name: "Outside", image: "https://cdn-icons-png.flaticon.com/128/1329/1329016.png" }
        ],

        // Objects (orange) - 1 column
        objects: [
            { id: 1049, name: "Headphones", image: "https://cdn-icons-png.flaticon.com/128/3578/3578440.png" },
            { id: 1050, name: "Bunny", image: "https://cdn-icons-png.flaticon.com/128/375/375073.png" },
            { id: 1051, name: "iPad", image: "https://cdn-icons-png.flaticon.com/128/821/821749.png" },
            { id: 1052, name: "Toy", image: "https://cdn-icons-png.flaticon.com/128/3081/3081993.png" }
        ]
    };

    // Place words in grid cells by column group
    columnGroups.forEach(group => {
        const typeWords = words[group.type] || [];
        let wordIndex = 0;

        // Distribute words across columns for this type
        for (let colIdx = 0; colIdx < group.columns.length && wordIndex < typeWords.length; colIdx++) {
            const columnIndex = group.columns[colIdx];

            // Fill column from top to bottom (max 4 rows)
            for (let rowIndex = 0; rowIndex < 4 && wordIndex < typeWords.length; rowIndex++) {
                gridCells[columnIndex][rowIndex] = {
                    ...typeWords[wordIndex],
                    type: group.type,
                    color: group.color
                };
                wordIndex++;
            }
        }
    });

    // Create HTML elements for the grid
    // We'll use CSS grid to layout the elements
    for (let rowIndex = 0; rowIndex < 4; rowIndex++) {
        for (let colIndex = 0; colIndex < 10; colIndex++) {
            const cell = gridCells[colIndex][rowIndex];
            const gridItem = document.createElement('div');

            // Set the grid position
            gridItem.style.gridColumn = colIndex + 1;
            gridItem.style.gridRow = rowIndex + 1;

            if (cell) {
                // Create a card for the cell
                gridItem.className = `communication-card word-${cell.type}`;
                gridItem.setAttribute('data-id', cell.id);
                gridItem.setAttribute('data-name', cell.name);
                gridItem.style.backgroundColor = cell.color;

                gridItem.innerHTML = `
                    <img src="${cell.image}" alt="${cell.name}">
                    <p>${cell.name}</p>
                `;

                // Add direct click handler for speech
                gridItem.addEventListener('click', function() {
                    console.log("Card clicked:", cell.name);

                    // Speak the word
                    if (typeof window.speak === 'function') {
                        window.speak(cell.name);
                    } else {
                        directSpeak(cell.name);
                    }

                    // Add to message
                    addToMessage(cell);
                });
            } else {
                // Empty cell
                gridItem.className = 'placeholder';
            }

            coreGrid.appendChild(gridItem);
        }
    }

    console.log("Core vocabulary initialized with vertical column layout");
}
            // Initialize category buttons
            function initCategories() {
                console.log("Initializing categories...");
                const categoriesSection = document.getElementById('categories-section');
                if (!categoriesSection) {
                    console.error("Could not find categories-section element!");
                    return;
                }

                categoriesSection.innerHTML = '';

                vocabularyData.categories.forEach(category => {
                    const button = document.createElement('div');
                    button.className = `category-card category-button`;
                    button.style.backgroundColor = category.color;
                    button.setAttribute('data-category', category.category);

                    button.innerHTML = `
                        <img src="${category.image}" alt="${category.name}">
                        <p>${category.name}</p>
                    `;

                    button.addEventListener('click', function() {
                        const categoryName = this.getAttribute('data-category');
                        showFringeVocabulary(categoryName);

                        // Highlight active category
                        document.querySelectorAll('.category-button').forEach(btn => {
                            btn.classList.remove('active');
                        });
                        this.classList.add('active');
                    });

                    categoriesSection.appendChild(button);
                });

                console.log("Categories initialized with " + vocabularyData.categories.length + " items");
            }

            // Show fringe vocabulary for a specific category
            function showFringeVocabulary(categoryName) {
                console.log("Showing fringe vocabulary for: " + categoryName);
                const fringeGrid = document.getElementById('fringe-grid');
                if (!fringeGrid) {
                    console.error("Could not find fringe-grid element!");
                    return;
                }

                // Update active category
                activeCategory = categoryName;

                // Clear current fringe grid
                fringeGrid.innerHTML = '';

                // Update section title
                const fringeTitle = document.getElementById('fringe-title');
                if (fringeTitle) {
                    const category = vocabularyData.categories.find(cat => cat.category === categoryName);
                    fringeTitle.textContent = category ? category.name : 'Category';
                }

                // Check if we have vocabulary for this category
                if (vocabularyData.fringe[categoryName]) {
                    vocabularyData.fringe[categoryName].forEach(item => {
                        const card = createCommunicationCard(item);
                        fringeGrid.appendChild(card);
                    });
                    console.log("Loaded " + vocabularyData.fringe[categoryName].length + " items for category: " + categoryName);
                } else {
                    console.warn("No vocabulary found for category: " + categoryName);
                }
            }

            // Check if keyboardInput is available from common.js, otherwise provide implementation
            function setupKeyboardInput() {
                if (typeof window.setupKeyboardInput === 'function') {
                    window.setupKeyboardInput();
                    return;
                }

                console.log("Setting up keyboard input (local implementation)");
                const keyboardToggle = document.getElementById('toggle-keyboard');
                const textInputArea = document.getElementById('text-input-area');
                const textInput = document.getElementById('text-input');
                const addTextBtn = document.getElementById('add-text-btn');

                if (keyboardToggle && textInputArea && textInput && addTextBtn) {
                    keyboardToggle.addEventListener('click', function() {
                        // Toggle visibility of text input area
                        if (textInputArea.style.display === 'none') {
                            textInputArea.style.display = 'flex';
                            textInput.focus();
                        } else {
                            textInputArea.style.display = 'none';
                        }
                    });

                    // Handle adding the typed text
                    addTextBtn.addEventListener('click', function() {
                        addTypedText();
                    });

                    // Also add it when pressing Enter
                    textInput.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            addTypedText();
                        }
                    });
                } else {
                    console.warn("Some keyboard input elements not found");
                }
            }

            // Add typed text to the message
            function addTypedText() {
                if (typeof window.addTypedText === 'function') {
                    window.addTypedText();
                    return;
                }

                const textInput = document.getElementById('text-input');
                if (!textInput || !textInput.value.trim()) return;

                // Create a custom item from the typed text
                const customText = textInput.value.trim();
                const customItem = {
                    id: 'typed-' + Date.now(),
                    name: customText,
                    image: 'https://cdn-icons-png.flaticon.com/128/1250/1250615.png', // Keyboard icon
                    type: 'typed',
                    color: '#7f8c8d'
                };

                // Add to message
                addToMessage(customItem);

                // Clear the input
                textInput.value = '';
                textInput.focus();
            }

            // Add a word to the message bar if not provided in common.js
            function addToMessage(item) {
                if (typeof window.addToMessage === 'function') {
                    window.addToMessage(item);
                    return;
                }

                console.log("Adding to message: " + item.name);
                const messageBar = document.getElementById('message-bar');
                if (!messageBar) {
                    console.error("Could not find message-bar element!");
                    return;
                }

                const messageCard = document.createElement('div');
                messageCard.className = 'message-card';
                messageCard.setAttribute('data-id', item.id);
                messageCard.setAttribute('data-name', item.name);

                messageCard.innerHTML = `
                    <img src="${item.image}" alt="${item.name}" style="width: 30px; height: 30px;">
                    <p>${item.name}</p>
                    <button class="remove-btn">×</button>
                `;

                // Add delete functionality
                messageCard.querySelector('.remove-btn').addEventListener('click', function(e) {
                    e.stopPropagation();
                    messageCard.remove();
                    updateFullMessage();
                });

                // Add click to speak individual word
                messageCard.addEventListener('click', function() {
                    if (typeof window.speak === 'function') {
                        window.speak(item.name);
                    } else {
                        directSpeak(item.name);
                    }
                });

                messageBar.appendChild(messageCard);
                updateFullMessage();
            }

            // Update the full message text if not provided in common.js
            function updateFullMessage() {
                if (typeof window.updateFullMessage === 'function') {
                    return window.updateFullMessage();
                }

                const messageBar = document.getElementById('message-bar');
                if (!messageBar) return;

                const fullMessage = Array.from(messageBar.querySelectorAll('.message-card'))
                    .map(card => card.getAttribute('data-name'))
                    .join(' ');

                const speakButton = document.getElementById('speak-button');
                if (speakButton) {
                    if (fullMessage.length > 0) {
                        speakButton.removeAttribute('disabled');
                    } else {
                        speakButton.setAttribute('disabled', 'true');
                    }
                }

                return fullMessage;
            }

            // Initialize the page when DOM is loaded
            document.addEventListener('DOMContentLoaded', function() {
                console.log("DOM loaded for communicate page");
                setTimeout(initCommunicatePage, 100); // Small delay to ensure DOM is fully ready
            });

            // Also initialize if DOM is already loaded
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                console.log("DOM already loaded, initializing communicate page now");
                setTimeout(initCommunicatePage, 100); // Small delay to ensure DOM is fully ready
            }