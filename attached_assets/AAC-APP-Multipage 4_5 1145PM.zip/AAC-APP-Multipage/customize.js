// customize.js - Functionality for the customization page

// Voice options for selection
let availableVoices = [];
let voicesLoaded = false;

// Initialize the customization page
function initCustomizePage() {
    // Initialize voice selection
    initVoiceSelection();

    // Set up voice control sliders
    setupVoiceControls();

    // Set up save and reset buttons
    setupSettingsActions();
}

// Initialize voice selection options
function initVoiceSelection() {
    const voiceOptions = document.getElementById('voice-options');
    if (!voiceOptions) return;

    // Function to populate voices
    const populateVoices = () => {
        availableVoices = speechSynthesis.getVoices();
        voicesLoaded = true;

        // Clear existing options
        voiceOptions.innerHTML = '';

        // Select voices - we'll pick 4 diverse options
        const selectedVoices = selectDiverseVoices(availableVoices, 4);

        // Create voice option cards
        selectedVoices.forEach((voice, index) => {
            const card = document.createElement('div');
            card.className = 'voice-option';
            card.setAttribute('data-voice-uri', voice.voiceURI);

            // Check if this is the currently selected voice
            if (voice.voiceURI === voiceSettings.voiceURI) {
                card.classList.add('selected');
            }

            // Pick an appropriate icon based on voice characteristics
            const icon = getVoiceIcon(voice, index);

            card.innerHTML = `
                <img src="${icon}" alt="Voice">
                <h3>${getSimpleVoiceName(voice)}</h3>
                <p>${voice.lang || 'Default'}</p>
            `;

            // Add click event to select this voice
            card.addEventListener('click', function() {
                // Remove selected class from all options
                document.querySelectorAll('.voice-option').forEach(option => {
                    option.classList.remove('selected');
                });

                // Add selected class to this option
                this.classList.add('selected');

                // Update voice settings
                voiceSettings.voiceURI = voice.voiceURI;

                // Show notification
                showNotification(`Selected voice: ${getSimpleVoiceName(voice)}`);
            });

            voiceOptions.appendChild(card);
        });
    };

    // Get available voices - this might need to wait for voices to load
    if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = populateVoices;
    }

    // Try loading voices immediately in case they're already available
    if (speechSynthesis.getVoices().length > 0) {
        populateVoices();
    }
}

// Select a diverse set of voices from the available options
function selectDiverseVoices(voices, count) {
    if (voices.length <= count) return voices;

    const selectedVoices = [];

    // Try to include at least one male and one female voice
    const femaleVoice = voices.find(v => 
        v.name.toLowerCase().includes('female') || 
        v.name.toLowerCase().includes('woman') ||
        v.name.toLowerCase().includes('girl'));

    const maleVoice = voices.find(v => 
        v.name.toLowerCase().includes('male') || 
        v.name.toLowerCase().includes('man') ||
        v.name.toLowerCase().includes('boy'));

    if (femaleVoice) selectedVoices.push(femaleVoice);
    if (maleVoice) selectedVoices.push(maleVoice);

    // Try to find a child-friendly voice
    if (selectedVoices.length < count) {
        const childVoice = voices.find(v => 
            !selectedVoices.includes(v) && 
            (v.name.toLowerCase().includes('child') || 
             v.name.toLowerCase().includes('junior') ||
             v.name.toLowerCase().includes('kid')));

        if (childVoice) selectedVoices.push(childVoice);
    }

    // Add other voices until we reach the desired count
    for (let i = 0; i < voices.length && selectedVoices.length < count; i++) {
        if (!selectedVoices.includes(voices[i])) {
            selectedVoices.push(voices[i]);
        }
    }

    return selectedVoices;
}

// Get a simpler name for the voice by removing vendor prefixes
function getSimpleVoiceName(voice) {
    // Extract a simpler name without vendor prefixes
    let name = voice.name;

    // Remove common prefixes
    const prefixes = ['Microsoft ', 'Google ', 'Apple ', 'Amazon ', 'Siri '];
    prefixes.forEach(prefix => {
        if (name.startsWith(prefix)) {
            name = name.substring(prefix.length);
        }
    });

    // If the name has "Voice" in it, try to simplify further
    if (name.includes('Voice')) {
        name = name.replace(' Voice', '');
    }

    return name;
}

// Get an appropriate icon for the voice based on its characteristics
function getVoiceIcon(voice, index) {
    // Try to determine voice characteristics from the name
    const name = voice.name.toLowerCase();

    if (name.includes('female') || name.includes('woman') || name.includes('girl')) {
        return "https://cdn-icons-png.flaticon.com/128/4140/4140047.png";
    }

    if (name.includes('male') || name.includes('man') || name.includes('boy')) {
        if (name.includes('kid') || name.includes('child') || name.includes('junior')) {
            return "https://cdn-icons-png.flaticon.com/128/3624/3624963.png";
        } else {
            return "https://cdn-icons-png.flaticon.com/128/4140/4140048.png";
        }
    }

    // If we can't determine gender, use a generic icon based on index
    const genericIcons = [
        "https://cdn-icons-png.flaticon.com/128/6316/6316041.png",
        "https://cdn-icons-png.flaticon.com/128/6316/6316043.png",
        "https://cdn-icons-png.flaticon.com/128/6316/6316042.png",
        "https://cdn-icons-png.flaticon.com/128/6316/6316048.png"
    ];

    return genericIcons[index % genericIcons.length];
}

// Set up voice control sliders
function setupVoiceControls() {
    // Speed control
    const speedSlider = document.getElementById('voice-speed');
    const speedValue = document.getElementById('speed-value');

    if (speedSlider && speedValue) {
        // Set initial value from settings
        speedSlider.value = voiceSettings.rate;
        speedValue.textContent = voiceSettings.rate.toFixed(1);

        // Add change event
        speedSlider.addEventListener('input', function() {
            const value = parseFloat(this.value);
            voiceSettings.rate = value;
            speedValue.textContent = value.toFixed(1);
        });
    }

    // Pitch control
    const pitchSlider = document.getElementById('voice-pitch');
    const pitchValue = document.getElementById('pitch-value');

    if (pitchSlider && pitchValue) {
        // Set initial value from settings
        pitchSlider.value = voiceSettings.pitch;
        pitchValue.textContent = voiceSettings.pitch.toFixed(1);

        // Add change event
        pitchSlider.addEventListener('input', function() {
            const value = parseFloat(this.value);
            voiceSettings.pitch = value;
            pitchValue.textContent = value.toFixed(1);
        });
    }

    // Volume control
    const volumeSlider = document.getElementById('voice-volume');
    const volumeValue = document.getElementById('volume-value');

    if (volumeSlider && volumeValue) {
        // Set initial value from settings
        volumeSlider.value = voiceSettings.volume;
        volumeValue.textContent = voiceSettings.volume.toFixed(1);

        // Add change event
        volumeSlider.addEventListener('input', function() {
            const value = parseFloat(this.value);
            voiceSettings.volume = value;
            volumeValue.textContent = value.toFixed(1);
        });
    }

    // Test voice button
    const testVoiceBtn = document.getElementById('test-voice-btn');

    if (testVoiceBtn) {
        testVoiceBtn.addEventListener('click', function() {
            speak("This is a test of the selected voice with current settings.");
        });
    }
}

// Set up save and reset buttons
function setupSettingsActions() {
    // Save settings button
    const saveBtn = document.getElementById('save-voice-settings');

    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            // Save the current settings to localStorage
            saveVoiceSettings();
            showNotification('Voice settings saved successfully!');
        });
    }

    // Reset to default button
    const resetBtn = document.getElementById('reset-voice-settings');

    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            // Reset to default settings
            voiceSettings = {
                voiceURI: "",
                rate: 1.0,
                pitch: 1.0,
                volume: 1.0
            };

            // Update UI to reflect default settings
            const speedSlider = document.getElementById('voice-speed');
            const speedValue = document.getElementById('speed-value');
            if (speedSlider && speedValue) {
                speedSlider.value = 1.0;
                speedValue.textContent = "1.0";
            }

            const pitchSlider = document.getElementById('voice-pitch');
            const pitchValue = document.getElementById('pitch-value');
            if (pitchSlider && pitchValue) {
                pitchSlider.value = 1.0;
                pitchValue.textContent = "1.0";
            }

            const volumeSlider = document.getElementById('voice-volume');
            const volumeValue = document.getElementById('volume-value');
            if (volumeSlider && volumeValue) {
                volumeSlider.value = 1.0;
                volumeValue.textContent = "1.0";
            }

            // Remove selected class from all voice options
            document.querySelectorAll('.voice-option').forEach(option => {
                option.classList.remove('selected');
            });

            // Save the reset settings
            saveVoiceSettings();

            showNotification('Voice settings reset to default!');
        });
    }
}

// Initialize the page when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM loaded for customize page");
    initCustomizePage();
});

// Also initialize if DOM is already loaded
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    console.log("DOM already loaded, initializing customize page now");
    initCustomizePage();
}